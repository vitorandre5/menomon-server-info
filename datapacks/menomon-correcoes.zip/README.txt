menomon-correcoes: os 12 callbacks battle_victory do Legendary Monuments 8.2 envolvidos em "t.loser.npc.is_npc ? { ... }".
Motivo: no Cobblemon 1.8.4, c.npc_losers inclui atores de tipo NPC que nao sao NPCs do Cobblemon (ex.: treinadores RCT);
neles t.loser.npc = 0 e q.player.set_npc_variable lanca ClassCastException -> PokemonBattle.stop -> crash do servidor
(TypeError write of undefined em sendBattleMessage). Gerado a partir do jar original do LM.
Tambem (2026-11-11): 4 loot tables do LM (dojo: dark/water tower spawner e tower_spawner_dark/water) com itens renomeados no
Cobblemon 1.8.4 (black/blue_apricorn_sprout -> *_apricorn_seed, tomato_berry -> tamato_berry); conquista toms_storage:unlock_redstone
(redstone_dust -> minecraft:redstone); icone da conquista cobblemonextrastructures:sprout_tower (bellsprout_statue inexistente -> bamboo).
3 loot tables do LM (dojo_towers/dark e water_tower_reward, npc_rewards/mustard_rewards) apontavam para chests/dojo_towers_vaults/tower_reward,
que nao existe -> chests/dojo_towers/tower_reward.

2026-11-12: data/cobblemon/tags/item/held/lucky_egg.json acrescenta o Oran Lucky Egg (Fight or Flight) a tag do Lucky Egg, para valer tambem nas batalhas por turnos e no CobbleAction.
